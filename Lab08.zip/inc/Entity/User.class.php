<?php

class User {

    //Properties
   

    //Setters

    //Getters
    

    //Verify the password
    function verifyPassword(string $passwordToVerify) {
        //Return a boolean based on verifying if the password given is correct for the current user
    }
}



?>