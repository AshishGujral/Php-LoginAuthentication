<?php

class Page  {

    public static $heading = "Change MEEEE!!";
    public static $studentID;
    public static $studentName;
    public static $notifications;

    
    static function header() { ?>
          
    <?php }

    
    static function footer()    { ?>        

    <?php }

    
    static function displayUserProfileSection(User $user) { ?>
        
    <?php }

    
    static function displayLoginSection() { ?>
    
    <?php }

    
    static function displayRegistrationSection() { ?>
    
    <?php }

    static function displayLogoutSection(){
            
    }

}