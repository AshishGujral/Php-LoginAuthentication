<?php

class UserDAO   {

    // Create a member to store the PDO agent

    // create the init function to start the PDO wrapper

    // function to create user
    static function createUser(User $user){
        // make sure the strings being stored in the database are cleaned 
        // and trimmed
        
        // query
        // bind
        // execute
        // you may return the rowCount

    }

    // get user detail
    static function getUser(string $email)  {
        
        // you know the drill
        // return the single result query

    }

    // update the current user profile
    // certainly you don't have the form to facilitate this
    // so, it is not needed in our app, but hey.. more practice is better!
    static function updateUser(string $email)    {

        // you know the drill
        // you may return the rowCount        

    }

    // get multiple users detail
    // It is not needed in our app, but hey.. more practice is better!
    static function getUsers()  {

        // you know the drill
        // return the multiple result query    

    }
    
    
}