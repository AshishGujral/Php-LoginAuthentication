<?php

class Validate {

    // create a function to validate the registration form
    // Please use filter to validate the inputs whenever possible    
    
    // What to validate?
    
    // Email should be email format

    // password
        // should be a 5 digits string
        // both password and password confirm needs to be exactly similar
    
    // Full Name should not be empty and cannot be numbers
        // Also replace occurences of semicolon, colon, comma, ampersand, 
        // dollar sign, < and > and any improper character with nothing

    // Avatar name should not be empty

    // Guild name should not be empty

    // One of the affiliation should be selected

    // One of the avatar images must be chosen

    // the function should update the page's notifications
    // you can also return some value to the calling function
    
}



?>