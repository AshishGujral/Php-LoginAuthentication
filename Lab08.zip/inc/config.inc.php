<?php

// set the folder path for the image files
define("IMAGES",'./images/');


// Set all the database things! double check with the PDOService class and your database 


// Set the error log things!

?>