<?php

// require once all the files

//Start the session


// If no form is submitted
    // Verify the Login

        //Initialize the user DAO

        //Get the current user thats logged in

        //Display page' element corresponding to the user details
    
    // if login is not verified, redirect to the login page

// else 
    // unser the session
    // destroy the session
    // display logout page's elements



?>