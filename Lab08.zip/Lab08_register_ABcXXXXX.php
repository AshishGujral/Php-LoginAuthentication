<?php

// require once all the files


//Check if the form was posted

    // If the form entries are valid
        // initialize the DAO

        // instantiate a new user
        // assemble the user data
        // create the user
        // send the user to the login page
    
    
// Display the page elements and registration form (with updated page notifications if any)


?>