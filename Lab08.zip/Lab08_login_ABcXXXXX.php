<?php

// require once all the files

//Check if the form was posted

    //Initialize the DAO

    //Get the current user 

    //if there is no such user, update the page notifications

    //otherwise, check the DAO returned an object of type user

        //Verify the password with the posted data
        
            //Start the session
            
            //Set the user to logged in. Remember, the username is email address 
            
            //Use header to send the user to the user profile page


            
// Display the page element
?>